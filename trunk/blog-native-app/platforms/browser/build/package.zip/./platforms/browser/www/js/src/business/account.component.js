import React,{Component} from 'react';

export default class AccountComponent extends Component{

    render(){
        return this.template();
    }

    template(){
        return (<div>account</div>);
    }
}