export const LOGIN='Login';
export const LOGOUT='Logout'