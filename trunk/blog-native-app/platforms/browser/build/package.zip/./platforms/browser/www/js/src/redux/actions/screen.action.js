export const OPEN='open';
export const CLOSE='close';