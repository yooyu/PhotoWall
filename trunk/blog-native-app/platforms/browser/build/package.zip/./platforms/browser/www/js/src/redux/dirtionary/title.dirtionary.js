export const PIC='图片';
export const VIDEO='视频';
export const ACCOUNT='我的账户';
export const MESSAGE='消息';
export const SHARE_PIC='分享图片';
export const SHARE_VID='分享视频';