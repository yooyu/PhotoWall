export const PHOTOGRAPH='photograph';
export const UNPHOTOGRAPH='unphotograph';