export const PIC='Picture';
export const VIDEO='Video';
export const ACCOUNT='Account';
export const MESSAGE='Message';
export const CAMERA='Camera';