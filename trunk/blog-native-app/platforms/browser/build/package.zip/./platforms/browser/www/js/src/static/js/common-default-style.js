import {white,blue100} from 'material-ui/styles/colors';

export const COMMON_FONT_COLOR=white;
export const COMMON_BACKGROUND_COLOR=blue100;